h = {"a" => "Jackson", "r" => "Rails"}

puts h["r"]