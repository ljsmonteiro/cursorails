if 1 != 2
    puts 7 % 2
else
    puts 'b'
end