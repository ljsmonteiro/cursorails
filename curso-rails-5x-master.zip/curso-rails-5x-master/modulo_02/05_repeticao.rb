# Each

['A','b',3].each do |item|
   puts "O valor lido foi: " + item.to_s
end


# While

i = 0
num = 5

while i <= num  do
   puts "Contando... " + i.to_s
   i += 1
end
