module Pagamento
  PI = 3.14
end
