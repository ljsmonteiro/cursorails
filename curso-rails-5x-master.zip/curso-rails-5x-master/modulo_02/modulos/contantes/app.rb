require_relative 'pagamento'

include Pagamento

puts Pagamento::PI
puts PI
