module Pagamento
  class Visa
    def pagando
      "pagando..."
    end
  end
end
