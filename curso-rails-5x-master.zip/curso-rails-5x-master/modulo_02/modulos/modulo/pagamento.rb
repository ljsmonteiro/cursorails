module Pagamento
  module Master
    def pagando
      "pagando..."
    end
  end
end
