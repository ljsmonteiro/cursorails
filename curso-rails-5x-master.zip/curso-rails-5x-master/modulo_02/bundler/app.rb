require 'cpf_utils'

puts CpfUtils.cpf_formatado