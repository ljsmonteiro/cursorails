class String
    def inverter
        self.reverse
    end
end

puts "Jackson".inverter